package ec.edu.puce;

import ec.edu.puce.sport.model.JugadorBasico;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Path("/sport")
public class SportController {

    private static final List<JugadorBasico> jugadores = new ArrayList<>();

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response crearJugadorBasico(JugadorBasico jugador) {
        //for (JugadorBasico jugadorTmp : jugadores) {
            //if (jugadorTmp.codigo() == jugador.codigo()){
                //return Response.status(Response.Status.BAD_REQUEST)
                        //.entity("El codigo de usuario ya existe")
                        //.build();
            //}


        JugadorBasico jugadorIntermedio = new JugadorBasico(
                UUID.randomUUID().toString(),
                jugador.nombre(),
                jugador.fecha());



        System.out.println("El jugador es: %s".formatted(jugador.nombre()));
        jugadores.add(jugadorIntermedio); //aqui, reemplazar a jugador para usar lo comentado
        return Response.status(Response.Status.CREATED).entity(jugadorIntermedio).build();
    }

    @GET
    @Path("/jugadores")
    @Produces(MediaType.APPLICATION_JSON)

    public Response obtenerJugadores() {
        return Response.ok().entity(jugadores).build();
    }
}